package com.example.template_t

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
