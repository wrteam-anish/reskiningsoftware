class {{className}} {



}